
package pacotes;


public class CalcFuncionario {
    private Double salarioBruto, inss, Ir, salarioLiquido, fgts;
    
    public CalcFuncionario(Double salarioBruto){
        this.setSalarioBruto(salarioBruto);
    }

    public Double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(Double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public Double getInss() {
        return inss;
    }

    public void setInss(Double inss) {
        this.inss = inss;
    }

    public Double getIr() {
        return Ir;
    }

    public void setIr(Double Ir) {
        this.Ir = Ir;
    }

    public Double getSalarioLiquido() {
        return salarioLiquido;
    }

    public void setSalarioLiquido(Double salarioLiquido) {
        this.salarioLiquido = salarioLiquido;
    }

    public Double getFgts() {
        return fgts;
    }

    public void setFgts(Double fgts) {
        this.fgts = fgts;
    }
    
        public void calculoFgts(Double ftgs){
            this.setFgts(salarioBruto * (0.08));
        }
        
        public void calcularInss(Double inss, Double salarioBruto){
            if(this.getSalarioBruto() <= 1045){
                this.setInss(salarioBruto * (7.5/100));
            }else if(this.getSalarioBruto() <= 2089){
                this.setInss(salarioBruto * (9/100));
            }else if(this.getSalarioBruto() <= 3134){
                this.setInss(salarioBruto * (12/100));
            }else if(this.getSalarioBruto() > 6101){
                this.setInss(salarioBruto * (14/100));
            }else{
                System.out.println("erro");
            }
            
            
        }
        
         public void calcularIr(Double Ir){
             if(this.getSalarioBruto() < 1903){
             Ir = salarioBruto * (7.5/100);
             }else if(this.getSalarioBruto() < 2826){
             Ir = salarioBruto * (15/100);
             }else if(this.getSalarioBruto() < 3751){ Ir=salarioBruto * (15/100);}
             else if(this.getSalarioBruto() < 4664){Ir = salarioBruto * (22.5/100);}
             if(this.getSalarioBruto() > 4664){ Ir = salarioBruto * (27.5/100);}
         }
         
         public void calcularSalarioLiquido(Double SalarioLiquido){
         salarioLiquido = (salarioBruto - (inss + Ir));
         }
}
